{{ $emailLog->body_text }}
