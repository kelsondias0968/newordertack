{!! $emailLog->body_html !!}
